"""
Week 2 Task: Logistics Data Collection, Cleaning, and Preprocessing
Run: python logistics_preprocessing.py
Input: shipments_raw.csv
Outputs are saved in the output/ folder.
"""

from pathlib import Path
import pandas as pd
import numpy as np
from sklearn.preprocessing import MinMaxScaler

BASE_DIR = Path(__file__).resolve().parent
INPUT_FILE = BASE_DIR / "shipments_raw.csv"
OUTPUT_DIR = BASE_DIR / "output"
OUTPUT_DIR.mkdir(exist_ok=True)


def inspect_data(df):
    """Print basic quality information before cleaning."""
    print("\n" + "=" * 65)
    print("1. INITIAL DATA PROFILE")
    print("=" * 65)
    print(f"Rows: {df.shape[0]} | Columns: {df.shape[1]}")
    print("\nColumn data types:")
    print(df.dtypes)
    print("\nMissing values per column:")
    print(df.isna().sum())
    print(f"\nExact duplicate rows: {df.duplicated().sum()}")
    print("\nNumeric summary:")
    numeric_df = df.select_dtypes(include=["number"])
    print(numeric_df.describe().round(2))


def clean_data(df):
    """Clean data while preserving the original raw file."""
    df = df.copy()
    starting_rows = len(df)

    # Remove only exact duplicate records
    df = df.drop_duplicates().copy()
    exact_duplicates_removed = starting_rows - len(df)

    # Standardize text fields
    for col in ["delivery_status", "transport_mode", "warehouse"]:
        df[col] = df[col].astype("string").str.strip()

    df["delivery_status"] = df["delivery_status"].str.title()
    df["transport_mode"] = df["transport_mode"].str.title()
    df["warehouse"] = df["warehouse"].fillna("Unknown")

    # Convert dates and numeric values
    df["order_date"] = pd.to_datetime(df["order_date"], errors="coerce")
    df["delivery_date"] = pd.to_datetime(df["delivery_date"], errors="coerce")
    numeric_cols = ["distance_km", "shipping_cost", "weight_kg"]
    for col in numeric_cols:
        df[col] = pd.to_numeric(df[col], errors="coerce")

    # Flag repeated shipment IDs for review (do not silently delete conflicting IDs)
    duplicate_id_mask = df.duplicated("shipment_id", keep=False)
    duplicate_ids = df.loc[duplicate_id_mask].copy()
    duplicate_ids.to_csv(OUTPUT_DIR / "duplicate_shipment_ids_for_review.csv", index=False)

    # Impossible negative measurements are set to missing for transparent handling
    invalid_counts = {}
    for col in numeric_cols:
        invalid_counts[col] = int((df[col] < 0).sum())
        df.loc[df[col] < 0, col] = np.nan

    # Missing numeric values are filled with column medians
    # For real projects, confirm this is appropriate before imputing.
    imputation_values = {}
    for col in numeric_cols:
        median_value = df[col].median()
        imputation_values[col] = float(median_value) if pd.notna(median_value) else None
        df[col] = df[col].fillna(median_value)

    # Delivery dates are not invented. Duration stays missing if dates are missing.
    df["delivery_days"] = (df["delivery_date"] - df["order_date"]).dt.days
    negative_duration_count = int((df["delivery_days"] < 0).sum())
    df.loc[df["delivery_days"] < 0, "delivery_days"] = np.nan

    # IQR outlier detection: flag values; do not automatically delete them.
    outlier_parts = []
    for col in ["distance_km", "shipping_cost", "weight_kg", "delivery_days"]:
        values = df[col].dropna()
        if len(values) < 4:
            continue
        q1 = values.quantile(0.25)
        q3 = values.quantile(0.75)
        iqr = q3 - q1
        lower = q1 - 1.5 * iqr
        upper = q3 + 1.5 * iqr
        mask = df[col].notna() & ((df[col] < lower) | (df[col] > upper))
        flagged = df.loc[mask, ["shipment_id", col]].copy()
        if not flagged.empty:
            flagged["column"] = col
            flagged["lower_bound"] = lower
            flagged["upper_bound"] = upper
            flagged["observed_value"] = flagged[col]
            outlier_parts.append(flagged[["shipment_id", "column", "observed_value",
                                          "lower_bound", "upper_bound"]])

    if outlier_parts:
        outliers = pd.concat(outlier_parts, ignore_index=True)
    else:
        outliers = pd.DataFrame(columns=[
            "shipment_id", "column", "observed_value", "lower_bound", "upper_bound"
        ])
    outliers.to_csv(OUTPUT_DIR / "outlier_report.csv", index=False)

    # Record processing summary
    summary = {
        "input_rows": starting_rows,
        "rows_after_exact_duplicate_removal": len(df),
        "exact_duplicate_rows_removed": exact_duplicates_removed,
        "repeated_shipment_id_rows_flagged_for_review": int(duplicate_id_mask.sum()),
        "negative_distance_values_found": invalid_counts["distance_km"],
        "negative_shipping_cost_values_found": invalid_counts["shipping_cost"],
        "negative_weight_values_found": invalid_counts["weight_kg"],
        "negative_delivery_durations_found": negative_duration_count,
        "outlier_flags": len(outliers),
        "remaining_missing_values": int(df.isna().sum().sum()),
        "median_imputation_values": imputation_values,
    }
    return df, summary


def normalize_data(cleaned):
    """Create a separate dataset with Min-Max scaled numeric features."""
    columns = ["distance_km", "shipping_cost", "weight_kg"]
    normalized = cleaned.copy()
    scaler = MinMaxScaler()
    normalized[[f"{c}_normalized" for c in columns]] = scaler.fit_transform(cleaned[columns])
    return normalized


def main():
    if not INPUT_FILE.exists():
        raise FileNotFoundError(
            f"Input file not found: {INPUT_FILE}\n"
            "Keep shipments_raw.csv in the same folder as this script."
        )

    raw = pd.read_csv(INPUT_FILE)
    inspect_data(raw)

    cleaned, summary = clean_data(raw)
    cleaned.to_csv(OUTPUT_DIR / "shipments_cleaned.csv", index=False)

    normalized = normalize_data(cleaned)
    normalized.to_csv(OUTPUT_DIR / "shipments_normalized.csv", index=False)

    # Save a readable summary file
    summary_lines = [
        "LOGISTICS DATA PREPROCESSING SUMMARY",
        "=" * 40,
        f"Input rows: {summary['input_rows']}",
        f"Rows after exact duplicate removal: {summary['rows_after_exact_duplicate_removal']}",
        f"Exact duplicate rows removed: {summary['exact_duplicate_rows_removed']}",
        f"Rows with repeated shipment IDs flagged for review: {summary['repeated_shipment_id_rows_flagged_for_review']}",
        f"Negative distance values found: {summary['negative_distance_values_found']}",
        f"Negative shipping costs found: {summary['negative_shipping_cost_values_found']}",
        f"Negative weights found: {summary['negative_weight_values_found']}",
        f"Negative delivery durations found: {summary['negative_delivery_durations_found']}",
        f"Outlier flags written: {summary['outlier_flags']}",
        f"Remaining missing cells: {summary['remaining_missing_values']}",
        f"Median imputation values: {summary['median_imputation_values']}",
        "",
        "Files created:",
        "- shipments_cleaned.csv",
        "- shipments_normalized.csv",
        "- outlier_report.csv",
        "- duplicate_shipment_ids_for_review.csv",
    ]
    (OUTPUT_DIR / "preprocessing_summary.txt").write_text(
        "\n".join(summary_lines), encoding="utf-8"
    )

    print("\n" + "=" * 65)
    print("2. PREPROCESSING SUMMARY")
    print("=" * 65)
    for line in summary_lines:
        print(line)

    print("\nCleaned data preview:")
    print(cleaned.head(10).to_string(index=False))
    print(f"\nCompleted successfully. Results saved to: {OUTPUT_DIR}")


if __name__ == "__main__":
    main()
