# Week 2 Logistics Data Preprocessing Project

## Requirements
- Python 3.10 or newer
- pandas
- numpy
- scikit-learn

Install packages:
```bash
python -m pip install pandas numpy scikit-learn
```

## Run
Keep `shipments_raw.csv` and `logistics_preprocessing.py` in the same folder, then run:
```bash
python logistics_preprocessing.py
```

## Input
`shipments_raw.csv` is a simulated logistics dataset with intentional issues:
- exact duplicate row
- missing delivery date, cost, weight, and warehouse
- inconsistent capitalization and whitespace
- negative distance
- unusually high cost/distance values

## Output
The script creates an `output` folder containing:
- `shipments_cleaned.csv`: cleaned data and `delivery_days`
- `shipments_normalized.csv`: cleaned data plus Min-Max normalized numeric features
- `outlier_report.csv`: IQR-flagged observations for review
- `duplicate_shipment_ids_for_review.csv`: repeated IDs that need review
- `preprocessing_summary.txt`: counts and processing notes

## Important methodological notes
- The data are simulated for a reproducible demonstration, not real company records.
- Only exact duplicate rows are removed automatically. Repeated shipment IDs are reported for review.
- Negative numeric measurements are treated as invalid and set to missing before median imputation.
- Missing delivery dates are not invented, so `delivery_days` can remain missing.
- IQR outliers are flagged, not automatically deleted, because unusual shipments can be valid.
- For predictive modelling, fit scaling on training data only to avoid data leakage.
